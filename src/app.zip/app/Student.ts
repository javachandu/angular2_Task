export class Student {  
    constructor( public name: string, public marks: number, public rollNumber: string,public status:string,public color:string) 
    {

        
    }  
} 